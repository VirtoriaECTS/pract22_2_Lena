package com.example.pract22_2

import androidx.room.*
import androidx.room.Dao
import kotlinx.coroutines.flow.Flow

@Dao
interface Dao {
    //запись
    @Insert
    fun insertItem(item: Item)

    //получение всей бд
    @Query("SELECT * FROM items")
    fun getAllItem(): Flow<List<Item>>
    //удаление
    @Delete
    suspend fun deleteItem(item: Item)
    //обновление
    @Update
    suspend fun updateItem(item: Item)
}
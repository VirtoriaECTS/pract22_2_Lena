package com.example.pract22_2

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import androidx.lifecycle.asLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ScreenStatistics : AppCompatActivity() {

    private val dataList = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_statistics)
        printInfo()
    }
    private fun printInfo() {
        val textList = findViewById<ListView>(R.id.listView)
        dataList.clear()

        val db = MainDb.getDb(this)

        db.getDao().getAllItem().asLiveData().observe(this) { list ->
            val updatedDataList = mutableListOf<Item>()
            list.forEach { item ->
                //val text = "id ${item.id}, type ${item.name} number ${item.number} fact ${item.fact} \n"
                // Создайте новый элемент Item и добавьте его в dataList
                val newItem = Item(id = item.id, name = item.name, height = item.height, weight = item.weight, abiliti = item.abiliti)
                updatedDataList.add(newItem)
            }

            // После завершения цикла, обновите dataList
            dataList.clear()
            dataList.addAll(updatedDataList)

            // Создайте или обновите адаптер
            val itemAdapter = ItemAdapter(this, dataList,
                onDeleteClick = { itemToDelete ->
                    // Здесь выполняйте удаление элемента из базы данных и обновление списка
                    val db = MainDb.getDb(this)
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            db.getDao().deleteItem(itemToDelete)
                            // После удаления, обновите список данных
                            printInfo()
                        } catch (e: Exception) {
                            // Обработка ошибки удаления, если произошла
                        }
                    }
                    printInfo()
                    printInfo()
                },
                onEditClick = { position ->
                    // Получаю рание данные
                    val db = MainDb.getDb(this)
                    var bdNewText: Array<String> = arrayOf("id", "name", "height", "weight", "ability")
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            bdNewText= arrayOf(position.id.toString(), position.name, position.height, position.weight, position.abiliti)
                        } catch (e: Exception) {
                            // Обработка ошибки удаления, если произошла
                        }
                    }
                    //изменения через AlertDiolog
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Измените данные")

                    // Создайте контейнер LinearLayout для размещения двух EditText
                    val layout = LinearLayout(this)
                    layout.orientation = LinearLayout.VERTICAL

                    // Создайте два EditText для ввода данных
                    val EditNumber = EditText(this)
                    val EditFakt = EditText(this)
                    val EditWeight = EditText(this)
                    val EditAbility = EditText(this)
                    // Установите хинты для EditText
                    EditNumber.hint = "Введите имя покемона"
                    EditFakt.hint = "Введите рост"
                    EditWeight.hint = "Введите вес"
                    EditAbility.hint = "Введите способности"
                    EditNumber.setText(bdNewText[1])
                    EditFakt.setText(bdNewText[2])
                    EditWeight.setText(bdNewText[3])
                    EditAbility.setText(bdNewText[4])
                    // Добавьте EditText к контейнеру
                    layout.addView(EditNumber)
                    layout.addView(EditFakt)

                    layout.addView(EditWeight)
                    layout.addView(EditAbility)

                    builder.setView(layout)

                    // Установите кнопку "OK" для сохранения данных
                    builder.setPositiveButton("OK") { dialog, _ ->
                        var number = EditNumber.text.toString()
                        var height = EditFakt.text.toString()
                        var weight = EditWeight.text.toString()
                        var ability = EditAbility.text.toString()

                        //запись в бд
                        //проверка
                        if(number.isEmpty()){
                            number = bdNewText[1];
                        }
                        if(height.isEmpty()){
                            height = bdNewText[2];
                        }
                        if(weight.isEmpty()){
                            weight = bdNewText[3];
                        }
                        if(ability.isEmpty()){
                            ability = bdNewText[4];
                        }
                        //сама запись
                        val item = Item(bdNewText[0].toInt(), number, height, weight, ability)
                        CoroutineScope(Dispatchers.IO).launch {
                            // Вызовите suspend-функцию updateItem в корутине
                            db.getDao().updateItem(item)
                        }
                        printInfo()

                    }

                    // Установите кнопку "Отмена" для закрытия диалога
                    builder.setNegativeButton("Отмена") { dialog, _ ->
                        dialog.cancel()
                    }

                    val dialog = builder.create()
                    dialog.show()
                    printInfo()

                })
            textList.adapter = itemAdapter

            // Уведомите адаптер о изменениях
            itemAdapter.notifyDataSetChanged()

        }
    }

    fun ButCleaAll(view: View) {
        val db = MainDb.getDb(this)
        CoroutineScope(Dispatchers.IO).launch {
            // Очистите все таблицы в базе данных
            db.clearAllTables()

            // После удаления данных, выполните операции обновления UI на главном потоке (если необходимо)
            withContext(Dispatchers.Main) {
                // Обновление UI, если необходимо
            }
        }
        printInfo()
    }
    fun AddNewButton(view: View) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Введите данные")

        // Создайте контейнер LinearLayout для размещения двух EditText
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        // Создайте два EditText для ввода данных
        val EditNumber = EditText(this)
        val EditFakt = EditText(this)

        // Установите хинты для EditText
        val EditWeight = EditText(this)
        val EditAbility = EditText(this)
        // Установите хинты для EditText
        EditNumber.hint = "Введите имя покемона"
        EditFakt.hint = "Введите рост"
        EditWeight.hint = "Введите вес"
        EditAbility.hint = "Введите способности"

        // Добавьте EditText к контейнеру
        layout.addView(EditNumber)
        layout.addView(EditFakt)
        layout.addView(EditWeight)
        layout.addView(EditAbility)
        builder.setView(layout)

        // Установите кнопку "OK" для сохранения данных
        builder.setPositiveButton("OK") { dialog, _ ->
            val number = EditNumber.text.toString()
            val height = EditFakt.text.toString()
            val weight = EditWeight.text.toString()
            val ability = EditAbility.text.toString()

            // Здесь можно обработать введенные данные (value1 и value2)
            //запись в бд
            if(number.isEmpty() || height.isEmpty() || weight.isEmpty() || ability.isEmpty()){
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Не сохранено")
                    .setMessage("Необходимо заполнить все поля")
                    .setPositiveButton("ОК") {
                            dialog, id ->  dialog.cancel()
                    }
                builder.create()
                builder.show()
            }
            else{
                //сама запись
                val db = MainDb.getDb(this)
                val item = Item(null, number, weight, height, ability)
                Thread{
                    db.getDao().insertItem(item)
                }.start()
                dialog.dismiss()
                printInfo()
            }

        }

        // Установите кнопку "Отмена" для закрытия диалога
        builder.setNegativeButton("Отмена") { dialog, _ ->
            dialog.cancel()
        }

        val dialog = builder.create()
        dialog.show()

    }



}
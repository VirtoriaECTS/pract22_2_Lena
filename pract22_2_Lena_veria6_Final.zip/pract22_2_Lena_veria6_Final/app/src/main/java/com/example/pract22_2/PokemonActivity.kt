package com.example.pract22_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class PokemonActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon)
    }
    private fun getResualt()
    {
        val findpocemon: EditText =findViewById(R.id.editText)
        val url = "https://pokeapi.co/api/v2/pokemon/${findpocemon.text.toString()}/"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val name = jsonObject.getString("name")
                    val height = jsonObject.getInt("height")
                    val weight = jsonObject.getInt("weight")
                    val abilities = jsonObject.getJSONArray("abilities")

                    // Extract and log the abilities
                    val abilityList = mutableListOf<String>()
                    for (i in 0 until abilities.length()) {
                        val abilityObject = abilities.getJSONObject(i)
                        val ability = abilityObject.getJSONObject("ability")
                        val abilityName = ability.getString("name")
                        abilityList.add(abilityName)
                    }


                    // Now, you can display the information in your TextView or LogCat
                    Log.d("MyLog", "Name: $name")
                    Log.d("MyLog", "Height: $height")
                    Log.d("MyLog", "Weight: $weight")
                    Log.d("MyLog", "Abilities: ${abilityList.joinToString(", ")}")

                    // You can also update a TextView with the information
                    val textInfoSet: TextView = findViewById(R.id.textinfo)
                    textInfoSet.text = "Name: $name\nHeight: $height\nWeight: $weight\nAbilities: ${abilityList.joinToString(", ")}"

                    //запись в бд
                    val db = MainDb.getDb(this)
                    val item = Item(null, name, height.toString(), weight.toString(), abilityList.joinToString())
                    Thread{
                        db.getDao().insertItem(item)
                    }.start()

                } catch (e: JSONException) {
                    Log.e("MyLog", "JSON Parsing error: ${e.message}")
                }
            },
            { error ->
                Log.d("MyLog", "Volley error: ${error.message}")
            })

        queue.add(stringRequest)
    }

    fun getResultBut(view: View) {
        getResualt()
    }

    fun perehod(view: View) {
        val intent = Intent(this, ScreenStatistics::class.java)
        startActivity(intent)
    }
}